//define quiz data

const quizData = [{
    question : "what does html stand for?",
    options : [
        "Hypertext Markup Language",
        "Hyper Trancefer Markup Language",
        "Hypertext Machine Language",
        "Hyperlink and Text markup Language"
    ],
    correct :0,
},

{
    question :
    "which css property is used to control the spacing between elements?",
    options : ["Margin", "Padding", "spacing", "border-spacing"],
    correct : 1,
},
{
    question : "what is the javascript function used to select an Html elements by its id?",
    options: [
        "document.query",
        "getElementsById",
        "selectElements",
        "finalElementsById",
    ],
    correct:1,
},
{
question : "In React.js which book is used to perform side effects in a function components ?",
options: ["useeffects", "useState", "useContext", "useReducer"],
correct:0,
},
{
    question: "which HTML tag is used to create an ordered list ?",
    options : ["<ul>", "<li>", "<ol>", "<dl>"],
    correct : 2,
},

];