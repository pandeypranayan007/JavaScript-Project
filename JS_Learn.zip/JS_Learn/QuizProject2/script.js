const quizDB = [
    {
        question : "Q1: What is full form of HTML?",
        a:"Hello to my land",
        b:"Hey Text Markup laguage",
        c:"HyperText Markup language",
        d:"hypotext markup language",
        ans: "ans4"
    },

    {   
        question: "Q2: Waht is full form of css?",
        a: "cascading style sheets",
        b:"cascading style sheep",
        c:"cartoon style sheets",
        d:"cascading supet sheets",
        ans: "ans1"
    },
    {
        question: "Q3: what is the full form of HTTP? ",
        a:"hypertxt transfer protocal",
        b:"hypertext test protocal",
        c: "hey transfer protocal",
        d: "hypertext transfer protocal",
        ans: "ans4"

    },
    {
        question:"Q4: what is full form js",
        a: "java",
        b: "script",
        c: "josh",
        d: "JavaScript",
        ans: "ans1"
    }
];

const question = document.querySelector('.question');
const option1 = document.querySelector('#option1');
const option2 = document.querySelector('#option2');
const option3 = document.querySelector('#option3');
const option4 = document.querySelector('#option4');

const submit = document.querySelector('#submit');
const answers = document.querySelectorAll('.answer');

let questionCount=0;
let score=0;

const loadQuestion =()=>{


    const questionList = quizDB[questionCount];
    question.innerHTML= questionList.question;

    option1.innerHTML= questionList.a;
    option2.innerHTML= questionList.b;
    option3.innerHTML= questionList.c;
    option4.innerHTML= questionList.d;
    
    
}



loadQuestion();

const getCheckAnswer =()=>{
    let answer;

    answers.array.forEach(element => {
        if(curAnsElem.checked){
            answer=curAnsElem.id
        }
        
    });
    return answer;
}

submit.addEventListener('click', ()=>{
    const checkedAnswer= getCheckAnswer();
    console.log(checkedAnswer);
    if(checkedAnswer==quizDB[questionCount].ans){
        score++;
    }
})
//onsole.log(quizDB[0]);

