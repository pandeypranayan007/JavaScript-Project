//define quiz data

const quizData = [{
    question : "what does html stand for?",
    options : [
        "Hypertext Markup Language",
        "Hyper Trancefer Markup Language",
        "Hypertext Machine Language",
        "Hyperlink and Text markup Language"
    ],
    correct :0,
},

{
    question :
    "which css property is used to control the spacing between elements?",
    options : ["Margin", "Padding", "spacing", "border-spacing"],
    correct : 1,
},
{
    question : "what is the javascript function used to select an Html elements by its id?",
    options: [
        "document.query",
        "getElementsById",
        "selectElements",
        "finalElementsById",
    ],
    correct:1,
},
{
question : "In React.js which book is used to perform side effects in a function components ?",
options: ["useeffects", "useState", "useContext", "useReducer"],
correct:0,
},
{
    question: "which HTML tag is used to create an ordered list ?",
    options : ["<ul>", "<li>", "<ol>", "<dl>"],
    correct : 2,
},

];


//step 1 : Javascript initilisation

const answerElm = document.querySelectorAll(".answer");
const [questionElm, option_1, option_2, option_3, option_4] = document.querySelectorAll("#question, .option_1, .option_2, .option_3, .option_4");

const submitBtn = document.querySelector("#submit");

const currentQuiz =0;
const score =0;

//step 3 :Load the quiz function

const loadQuiz = () =>{

     
    const {question, options} = quizData[currentQuiz];
    //console.log(question);

    questionElm.innerHTML = question;
  //  console.log(options);

  options.forEach((curOption,index)=>(window[`option_${index +1}`].innerText = curOption));
};


loadQuiz();


//step 4 : get selected answer function on button click

const getSelectedOption =()=>{
    let ans_index;
    answerElm.forEach((curOption, index)=>{
        if(curOption.checked){
            ans_index=index;
        }
    });
    return ans_index;

};

submitBtn.addEventListener("click", ()=>{
    const selectedOptionIndex= getSelectedOption();
    console.log(selectedOptionIndex);
});
