// console.log('hello world');
// console.log(32);
// console.log(true);
// console.log([34,2,1,2]);
// console.clear;



// for (let i=1; i<=100;i++){

// let f= i%3==0, b= i%5==0;
//     console.log(f? (b? 'fizzBuzz' : 'fizz'): b? 'buzz' : i);
    
    
// }
    
    
    
//     function abc(a){
    
//     return a*a;
    
    
    
    
//     }
//     let x= abc(3);
//     console.log(x);





    